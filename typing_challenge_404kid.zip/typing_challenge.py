import random
import time

# Word list (you can expand this!)
words = ["magic", "python", "studio", "keyboard", "adventure", "future", "404", "dragon", "space", "speed"]

def get_random_word():
    return random.choice(words)

def typing_game():
    print("🚀 Welcome to the 404 Typing Challenge!")
    input("Press Enter to start...")

    score = 0
    rounds = 10
    start_time = time.time()

    for i in range(rounds):
        word = get_random_word()
        print(f"\nWord {i+1}: {word}")
        typed = input("Type it: ")
        if typed.strip().lower() == word:
            print("✅ Correct!")
            score += 1
        else:
            print("❌ Oops! The correct word was:", word)

    end_time = time.time()
    total_time = end_time - start_time
    wpm = (score / total_time) * 60

    print("\n🎉 Game Over!")
    print(f"Correct words: {score}/{rounds}")
    print(f"Time taken: {round_time(total_time)} seconds")
    print(f"Your WPM: {round(wpm, 2)}")

def round_time(t):
    return str(round(t, 2))

if __name__ == "__main__":
    typing_game()
