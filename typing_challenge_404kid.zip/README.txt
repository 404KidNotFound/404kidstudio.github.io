404 KID STUDIO - Typing Challenge Game

How to Play:
1. Run the game using Python 3:
   python typing_challenge.py

2. Type the words as fast and accurately as you can.

3. At the end, you'll see how many words you got right and your words-per-minute (WPM) score.

Enjoy and share your high scores!

- 404 Kid Studio
